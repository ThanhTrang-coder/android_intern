package edu.hanu.app.Instagram;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import edu.hanu.mydesign.R;

public class InstagramActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instagram);
    }
}