package edu.hanu.app.Messenger.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import edu.hanu.app.Messenger.models.HorizontalModel;
import edu.hanu.mydesign.R;

public class HorizontalAdapter extends RecyclerView.Adapter<HorizontalAdapter.HorizontalHolder> {
    List<HorizontalModel> list;

    public HorizontalAdapter (List<HorizontalModel> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public HorizontalHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat_horizontal, parent, false);
        return new HorizontalHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HorizontalHolder holder, int position) {
        HorizontalModel item = list.get(position);
        holder.setData(item);
    }

    @Override
    public int getItemCount() {
        if (list != null) {
            list.size();
        }
        return 0;
    }

    public class HorizontalHolder extends RecyclerView.ViewHolder {
        CircleImageView user_avatar;
        TextView user_name;

        public HorizontalHolder(@NonNull View itemView) {
            super(itemView);

            user_avatar = itemView.findViewById(R.id.user_avatar);
            user_name = itemView.findViewById(R.id.user_name);
        }

        private void setData(HorizontalModel item) {
            user_avatar.setImageResource(item.getAvatar());
            user_name.setText(item.getUser_name());
        }
    }
}
