package edu.hanu.app.Messenger.models;

public class VerticalModel {
    private int avatar;
    private String user_name, content;

    public VerticalModel(int avatar, String user_name, String content) {
        this.avatar = avatar;
        this.user_name = user_name;
        this.content = content;
    }

    public int getAvatar() {
        return avatar;
    }

    public void setAvatar(int avatar) {
        this.avatar = avatar;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
