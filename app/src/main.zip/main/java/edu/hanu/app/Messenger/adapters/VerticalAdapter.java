package edu.hanu.app.Messenger.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import edu.hanu.app.Messenger.models.VerticalModel;
import edu.hanu.mydesign.R;

public class VerticalAdapter extends RecyclerView.Adapter<VerticalAdapter.VerticalHolder> {
    List<VerticalModel> list;

    public VerticalAdapter(List<VerticalModel> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public VerticalHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat_vertical, parent, false);
        return new VerticalHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VerticalHolder holder, int position) {
        VerticalModel item = list.get(position);
        holder.setData(item);
    }

    @Override
    public int getItemCount() {
        if (list != null) {
            list.size();
        }
        return 0;
    }

    public class VerticalHolder extends RecyclerView.ViewHolder {
          CircleImageView user_avatar;
          TextView user_name, content;

        public VerticalHolder(@NonNull View itemView) {
            super(itemView);

            user_avatar = itemView.findViewById(R.id.user_avatar);
            user_name = itemView.findViewById(R.id.user_name);
            content = itemView.findViewById(R.id.content);
        }

        private void setData(VerticalModel item) {
            user_avatar.setImageResource(item.getAvatar());
            user_name.setText(item.getUser_name());
            content.setText(item.getContent());
        }
    }
}
