package edu.hanu.app.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import edu.hanu.mydesign.R;

public class TestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);


    }
}