package edu.hanu.app.Messenger.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import edu.hanu.app.Messenger.adapters.HorizontalAdapter;
import edu.hanu.app.Messenger.adapters.VerticalAdapter;
import edu.hanu.app.Messenger.models.HorizontalModel;
import edu.hanu.app.Messenger.models.VerticalModel;
import edu.hanu.mydesign.R;

public class ChatFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_chat_messenger, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RecyclerView rvHorizontal = view.findViewById(R.id.rvHorizontal);
        LinearLayoutManager manager = new LinearLayoutManager(getContext(), RecyclerView.HORIZONTAL, false);
        rvHorizontal.setLayoutManager(manager);
        HorizontalAdapter adapter = new HorizontalAdapter(getList());
        rvHorizontal.setAdapter(adapter);

//        RecyclerView rvVertical = view.findViewById(R.id.rvVertical);
//        LinearLayoutManager manager1 = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);
//        rvVertical.setLayoutManager(manager1);
//        VerticalAdapter adapter1 = new VerticalAdapter(getList1());
//        rvVertical.setAdapter(adapter1);
    }

    private List<HorizontalModel> getList() {
        List<HorizontalModel> list = new ArrayList<>();
        list.add(new HorizontalModel(R.drawable.image6, "User name 1"));
        list.add(new HorizontalModel(R.drawable.image6, "User name 1"));
        list.add(new HorizontalModel(R.drawable.image6, "User name 1"));
        list.add(new HorizontalModel(R.drawable.image6, "User name 1"));
        list.add(new HorizontalModel(R.drawable.image6, "User name 1"));
        list.add(new HorizontalModel(R.drawable.image6, "User name 1"));
        list.add(new HorizontalModel(R.drawable.image6, "User name 1"));
        list.add(new HorizontalModel(R.drawable.image6, "User name 1"));
        list.add(new HorizontalModel(R.drawable.image6, "User name 1"));
        list.add(new HorizontalModel(R.drawable.image6, "User name 1"));

        return list;
    }

    private List<VerticalModel> getList1() {
        List<VerticalModel> list = new ArrayList<>();
        list.add(new VerticalModel(R.drawable.image6, "User name 1", "Content"));
        list.add(new VerticalModel(R.drawable.image6, "User name 1", "Content"));
        list.add(new VerticalModel(R.drawable.image6, "User name 1", "Content"));
        list.add(new VerticalModel(R.drawable.image6, "User name 1", "Content"));
        list.add(new VerticalModel(R.drawable.image6, "User name 1", "Content"));
        list.add(new VerticalModel(R.drawable.image6, "User name 1", "Content"));
        list.add(new VerticalModel(R.drawable.image6, "User name 1", "Content"));
        list.add(new VerticalModel(R.drawable.image6, "User name 1", "Content"));
        list.add(new VerticalModel(R.drawable.image6, "User name 1", "Content"));
        list.add(new VerticalModel(R.drawable.image6, "User name 1", "Content"));

        return list;
    }
}